import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white">
      <nav className="flex items-center justify-between px-8 py-6 max-w-6xl mx-auto">
        <div className="font-bold text-xl tracking-tight">BizFlow MY</div>
        <div className="flex gap-6 text-sm text-slate-300">
          <Link href="#features">Features</Link>
          <Link href="#pricing">Pricing</Link>
        </div>
      </nav>

      <section className="px-8 pt-24 pb-16 text-center">
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-tight">
          Quotation. Invoice. Tasks. <br />
          <span className="text-amber-400">Booking.</span> Team. All in one.
        </h1>
        <p className="mt-6 text-lg text-slate-300 max-w-2xl mx-auto">
          The business management platform built for Malaysian freelancers, service providers, and SMEs. Manage your entire business from one simple dashboard.
        </p>
        <div className="mt-10 flex justify-center gap-4">
          <a href="/signup" className="bg-amber-400 text-slate-950 px-8 py-3 rounded-full font-bold hover:bg-amber-300">Start Free</a>
          <a href="#how" className="border border-slate-600 px-8 py-3 rounded-full font-semibold hover:bg-slate-800">How It Works</a>
        </div>
      </section>

      <section id="features" className="max-w-6xl mx-auto px-8 py-24 grid md:grid-cols-3 gap-8">
        {[
          { title: "Quotations", desc: "Create, send, and convert professional quotations with PDF generation." },
          { title: "Invoices", desc: "Generate invoices, track payments, and manage overdue accounts." },
          { title: "Tasks", desc: "Assign tasks, manage deadlines, and connect tasks to customers." },
          { title: "Bookings", desc: "Schedule appointments, manage staff, and accept online bookings." },
          { title: "Team", desc: "Invite employees, control roles, and track team performance." },
          { title: "Reports", desc: "View real-time financial reports and business analytics." },
        ].map((f) => (
          <div key={f.title} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 hover:border-amber-400/40 transition">
            <h3 className="text-xl font-bold mb-2">{f.title}</h3>
            <p className="text-sm text-slate-400">{f.desc}</p>
          </div>
        ))}
      </section>

      <section id="pricing" className="max-w-5xl mx-auto px-8 py-24 text-center">
        <h2 className="text-4xl font-extrabold">Simple Pricing</h2>
        <p className="text-slate-400 mt-2">Start free, upgrade when you're ready.</p>
        <div className="mt-12 grid md:grid-cols-3 gap-6 text-left">
          {[
            { name: "Free", price: "RM0", desc: "5 invoices/month, 20 customers, 1 user", features: ["Basic dashboard", "Basic PDF"] },
            { name: "Pro", price: "RM29", desc: "Unlimited invoices and quotes", features: ["Expense tracking", "Task manager", "Booking system", "3 team members"] },
            { name: "Business", price: "RM59", desc: "Unlimited everything", features: ["Advanced reports", "10+ team members", "Custom branding", "Priority support"] },
          ].map((p) => (
            <div key={p.name} className="bg-slate-900 border border-slate-700 rounded-3xl p-8">
              <div className="text-sm text-slate-400">{p.name}</div>
              <div className="text-4xl font-extrabold mt-2">{p.price}<span className="text-base font-normal text-slate-500">/mo</span></div>
              <p className="text-sm text-slate-300 mt-3">{p.desc}</p>
              <ul className="mt-6 space-y-2 text-sm text-slate-300">
                {p.features.map((f) => <li key={f}>• {f}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <footer className="text-center text-slate-500 py-10 text-sm">
        © 2026 BizFlow MY — Built for Malaysian businesses.
      </footer>
    </main>
  );
}
