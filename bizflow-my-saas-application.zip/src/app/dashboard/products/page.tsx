"use client";
import { useState } from "react";

export default function ProductsPage() {
  const [search, setSearch] = useState("");
  const products = [
    { id: 1, name: "Website Development", sku: "WEB-001", category: "Services", price: 2500, unit: "Project" },
    { id: 2, name: "Logo Design", sku: "LOGO-001", category: "Services", price: 500, unit: "Project" },
    { id: 3, name: "Monthly Maintenance", sku: "MAIN-001", category: "Services", price: 150, unit: "Month" },
  ];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Products & Services</h1>
        <button className="bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">+ Add Product</button>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
          <input className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm w-72" placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-800">
            <tr>
              <th className="text-left px-6 py-3">Name</th>
              <th className="text-left px-6 py-3">SKU</th>
              <th className="text-left px-6 py-3">Category</th>
              <th className="text-left px-6 py-3">Price</th>
              <th className="text-left px-6 py-3">Unit</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                <td className="px-6 py-4 font-medium">{p.name}</td>
                <td className="px-6 py-4 text-slate-400">{p.sku}</td>
                <td className="px-6 py-4 text-slate-400">{p.category}</td>
                <td className="px-6 py-4 font-bold">RM {p.price}</td>
                <td className="px-6 py-4 text-slate-400">{p.unit}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
