"use client";
import { useState } from "react";

export default function CustomersPage() {
  const [search, setSearch] = useState("");
  const customers = [
    { id: 1, name: "Ahmad Enterprise", company: "Ahmad Construction", email: "ahmad@co.my", phone: "+6012-3456789", city: "Kuala Lumpur", outstanding: 1250 },
    { id: 2, name: "Sarah Design", company: "Sarah Creative", email: "sarah@design.my", phone: "+6012-9876543", city: "Penang", outstanding: 0 },
    { id: 3, name: "Mohd Renovation", company: "Mohd Renovation Sdn Bhd", email: "mohd@renov.my", phone: "+6019-1112222", city: "Johor Bahru", outstanding: 3200 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Customers</h1>
        <button className="bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">+ Add Customer</button>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
          <input className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm w-72" placeholder="Search customers..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-800">
            <tr>
              <th className="text-left px-6 py-3">Name</th>
              <th className="text-left px-6 py-3">Company</th>
              <th className="text-left px-6 py-3">Contact</th>
              <th className="text-left px-6 py-3">City</th>
              <th className="text-left px-6 py-3">Outstanding</th>
            </tr>
          </thead>
          <tbody>
            {customers.map(c => (
              <tr key={c.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                <td className="px-6 py-4 font-medium">{c.name}</td>
                <td className="px-6 py-4 text-slate-400">{c.company}</td>
                <td className="px-6 py-4 text-slate-400">{c.phone}</td>
                <td className="px-6 py-4 text-slate-400">{c.city}</td>
                <td className="px-6 py-4 font-bold text-amber-400">RM {c.outstanding.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
