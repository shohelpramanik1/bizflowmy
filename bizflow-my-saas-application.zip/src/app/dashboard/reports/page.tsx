"use client";

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-extrabold">Reports</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {["Sales Report", "Invoice Report", "Expense Report", "Profit & Loss", "Customer Report", "Product Report"].map(r => (
          <div key={r} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 hover:border-amber-400/40 transition">
            <h3 className="font-bold">{r}</h3>
            <p className="text-xs text-slate-400 mt-1">PDF / CSV export available.</p>
          </div>
        ))}
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center text-slate-400">
        <p>Generate and download professional business reports. Filter by date range, category, and status.</p>
        <button className="mt-4 bg-amber-400 text-slate-950 px-6 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">Generate Report</button>
      </div>
    </div>
  );
}
