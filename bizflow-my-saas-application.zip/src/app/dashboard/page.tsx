"use client";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from "recharts";

const data = [
  { month: "Jan", revenue: 8500, expenses: 3200 },
  { month: "Feb", revenue: 10200, expenses: 4100 },
  { month: "Mar", revenue: 14800, expenses: 3900 },
  { month: "Apr", revenue: 12000, expenses: 4200 },
];

const pieColors = ["#f59e0b", "#64748b", "#10b981", "#ef4444"];

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-extrabold">Dashboard</h1>
        <p className="text-slate-400 text-sm">Welcome back. Here's your business overview.</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { label: "Total Revenue", value: "RM 45,500", sub: "+12% vs last month" },
          { label: "Outstanding", value: "RM 8,250", sub: "3 unpaid invoices" },
          { label: "Overdue", value: "RM 2,450", sub: "2 overdue" },
          { label: "Net Profit", value: "RM 17,630", sub: "Expenses RM 7,850" },
        ].map((c) => (
          <div key={c.label} className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <div className="text-xs text-slate-400 uppercase tracking-wide">{c.label}</div>
            <div className="text-2xl font-extrabold mt-1">{c.value}</div>
            <div className="text-xs text-slate-500 mt-2">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
          <h3 className="font-bold mb-4">Revenue & Expenses</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <XAxis dataKey="month" tick={{ fill: "#94a3b8" }} />
                <YAxis tick={{ fill: "#94a3b8" }} />
                <Tooltip contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155" }} />
                <Bar dataKey="revenue" fill="#f59e0b" radius={[4,4,0,0]} />
                <Bar dataKey="expenses" fill="#64748b" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
          <h3 className="font-bold mb-4">Invoice Status</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={[{ name: "Paid", value: 65 }, { name: "Unpaid", value: 25 }, { name: "Overdue", value: 10 }]} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label>
                  {[0,1,2].map(i => <Cell key={i} fill={pieColors[i]} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
