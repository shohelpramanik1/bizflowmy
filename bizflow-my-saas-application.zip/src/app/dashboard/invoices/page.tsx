"use client";
import { useState } from "react";

export default function InvoicesPage() {
  const [search, setSearch] = useState("");
  const invoices = [
    { id: 1, number: "INV-2026-0001", customer: "Ahmad Enterprise", date: "2026-02-28", due: "2026-03-15", status: "Unpaid", total: 2500, paid: 0 },
    { id: 2, number: "INV-2026-0002", customer: "Sarah Design", date: "2026-02-25", due: "2026-03-10", status: "Paid", total: 500, paid: 500 },
    { id: 3, number: "INV-2026-0003", customer: "Mohd Renovation", date: "2026-03-01", due: "2026-03-15", status: "Overdue", total: 8500, paid: 2000 },
  ];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Invoices</h1>
        <button className="bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">+ New Invoice</button>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <input className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm w-72" placeholder="Search invoices..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-800">
            <tr>
              <th className="text-left px-6 py-3">Number</th>
              <th className="text-left px-6 py-3">Customer</th>
              <th className="text-left px-6 py-3">Due Date</th>
              <th className="text-left px-6 py-3">Status</th>
              <th className="text-left px-6 py-3">Total</th>
              <th className="text-left px-6 py-3">Paid</th>
              <th className="text-left px-6 py-3">Balance</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map(i => (
              <tr key={i.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                <td className="px-6 py-4 font-bold">{i.number}</td>
                <td className="px-6 py-4 text-slate-300">{i.customer}</td>
                <td className="px-6 py-4 text-slate-400">{i.due}</td>
                <td className="px-6 py-4"><span className={`text-xs font-bold px-2 py-1 rounded-md ${i.status === "Paid" ? "bg-green-900/40 text-green-400" : i.status === "Overdue" ? "bg-red-900/40 text-red-400" : "bg-amber-900/40 text-amber-400"}`}>{i.status}</span></td>
                <td className="px-6 py-4 font-bold">RM {i.total}</td>
                <td className="px-6 py-4 text-slate-300">RM {i.paid}</td>
                <td className="px-6 py-4 font-bold text-red-400">RM {i.total - i.paid}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
