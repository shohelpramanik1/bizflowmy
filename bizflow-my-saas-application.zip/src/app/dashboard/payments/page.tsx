"use client";
import { useState } from "react";

export default function PaymentsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Payments</h1>
        <button className="bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">+ Record Payment</button>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-800">
            <tr><th className="text-left py-3">Date</th><th className="text-left py-3">Customer</th><th className="text-left py-3">Invoice</th><th className="text-left py-3">Method</th><th className="text-left py-3">Amount</th></tr>
          </thead>
          <tbody>
            <tr className="border-b border-slate-800 hover:bg-slate-800/40"><td className="py-3">2026-03-01</td><td className="py-3">Sarah Design</td><td className="py-3">INV-2026-0002</td><td className="py-3">Bank Transfer</td><td className="py-3 font-bold">RM 500</td></tr>
            <tr className="border-b border-slate-800 hover:bg-slate-800/40"><td className="py-3">2026-03-02</td><td className="py-3">Ahmad Enterprise</td><td className="py-3">INV-2026-0001</td><td className="py-3">Cash</td><td className="py-3 font-bold">RM 2,500</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
