"use client";

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-extrabold">Settings</h1>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-6 max-w-2xl">
        <div>
          <label className="text-xs text-slate-400 block mb-1">Business Name</label>
          <input className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm" defaultValue="BizFlow Enterprise" />
        </div>
        <div>
          <label className="text-xs text-slate-400 block mb-1">Currency</label>
          <select className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white">
            <option>MYR / RM</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-slate-400 block mb-1">Tax Rate</label>
          <input type="number" className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm" defaultValue={6} />
          <p className="text-xs text-slate-500 mt-1">Note: Tax calculations are provided for reference only. Please verify against current Malaysian regulations.</p>
        </div>
        <button className="bg-amber-400 text-slate-950 px-6 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">Save Changes</button>
      </div>
    </div>
  );
}
