"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Users, Package, FileText, Receipt, BarChart3, Settings, Menu, X, CreditCard } from "lucide-react";
import { useState } from "react";

const nav = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Customers", href: "/dashboard/customers", icon: Users },
  { label: "Products", href: "/dashboard/products", icon: Package },
  { label: "Quotations", href: "/dashboard/quotations", icon: FileText },
  { label: "Invoices", href: "/dashboard/invoices", icon: Receipt },
  { label: "Payments", href: "/dashboard/payments", icon: CreditCard },
  { label: "Reports", href: "/dashboard/reports", icon: BarChart3 },
  { label: "Settings", href: "/dashboard/settings", icon: Settings },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  return (
    <div className="min-h-screen bg-slate-950 text-white flex">
      <aside className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 transform ${open ? "translate-x-0" : "-translate-x-full md:translate-x-0"} transition-transform`}>
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <Link href="/dashboard" className="font-extrabold text-xl tracking-tight">BizFlow MY</Link>
          <button className="md:hidden" onClick={() => setOpen(false)}><X size={20}/></button>
        </div>
        <nav className="p-4 space-y-1">
          {nav.map((item) => {
            const active = path === item.href;
            return (
              <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition ${active ? "bg-amber-400 text-slate-950" : "text-slate-300 hover:bg-slate-800 hover:text-white"}`}>
                <item.icon size={18} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>
      <main className="flex-1 min-h-screen">
        <div className="md:hidden flex items-center px-4 py-3 border-b border-slate-800">
          <button onClick={() => setOpen(true)}><Menu size={20}/></button>
          <span className="ml-4 font-bold">BizFlow</span>
        </div>
        <div className="p-6 md:p-10">{children}</div>
      </main>
    </div>
  );
}
