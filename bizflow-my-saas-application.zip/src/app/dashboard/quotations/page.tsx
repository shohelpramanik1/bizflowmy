"use client";
import { useState } from "react";

export default function QuotationsPage() {
  const [search, setSearch] = useState("");
  const quotes = [
    { id: 1, number: "QT-2026-0001", customer: "Ahmad Enterprise", date: "2026-02-15", status: "Sent", total: 2500 },
    { id: 2, number: "QT-2026-0002", customer: "Sarah Design", date: "2026-02-18", status: "Accepted", total: 500 },
    { id: 3, number: "QT-2026-0003", customer: "Mohd Renovation", date: "2026-02-20", status: "Draft", total: 8500 },
  ];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-extrabold">Quotations</h1>
        <button className="bg-amber-400 text-slate-950 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-300">+ New Quotation</button>
      </div>
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <input className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-sm w-72" placeholder="Search quotations..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-800">
            <tr><th className="text-left px-6 py-3">Number</th><th className="text-left px-6 py-3">Customer</th><th className="text-left px-6 py-3">Date</th><th className="text-left px-6 py-3">Status</th><th className="text-left px-6 py-3">Total</th></tr>
          </thead>
          <tbody>
            {quotes.map(q => (
              <tr key={q.id} className="border-b border-slate-800 hover:bg-slate-800/40">
                <td className="px-6 py-4 font-bold">{q.number}</td>
                <td className="px-6 py-4 text-slate-300">{q.customer}</td>
                <td className="px-6 py-4 text-slate-400">{q.date}</td>
                <td className="px-6 py-4"><span className={`text-xs font-bold px-2 py-1 rounded-md ${q.status === "Accepted" ? "bg-green-900/40 text-green-400" : q.status === "Sent" ? "bg-blue-900/40 text-blue-400" : "bg-slate-700 text-slate-300"}`}>{q.status}</span></td>
                <td className="px-6 py-4 font-bold">RM {q.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
