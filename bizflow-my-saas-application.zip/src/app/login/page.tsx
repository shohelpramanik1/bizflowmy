"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function LoginPage() {
  const router = useRouter();
  return (
    <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-4">
      <form onSubmit={e => { e.preventDefault(); router.push("/dashboard"); }} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
        <h1 className="text-2xl font-extrabold">Welcome back</h1>
        <input required type="email" placeholder="Email" className="w-full mt-4 px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" />
        <input required type="password" placeholder="Password" className="w-full mt-4 px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" />
        <button type="submit" className="mt-6 w-full bg-amber-400 text-slate-950 font-bold rounded-xl py-3 hover:bg-amber-300">Log In</button>
      </form>
    </main>
  );
}
