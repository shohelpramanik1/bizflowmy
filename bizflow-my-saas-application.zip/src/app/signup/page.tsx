"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SignupPage() {
  const [form, setForm] = useState({ email: "", fullName: "", password: "", businessName: "", country: "Malaysia", currency: "MYR" });
  const router = useRouter();

  return (
    <main className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-4">
      <form onSubmit={(e) => { e.preventDefault(); router.push("/dashboard"); }} className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
        <h1 className="text-2xl font-extrabold">Create your account</h1>
        <p className="text-sm text-slate-400 mt-1">Join thousands of Malaysian businesses using BizFlow.</p>
        <div className="mt-6 space-y-4">
          <input required placeholder="Full Name" className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} />
          <input required type="email" placeholder="Email" className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          <input required type="password" placeholder="Password" className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <input required placeholder="Business Name" className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-sm" value={form.businessName} onChange={e => setForm({ ...form, businessName: e.target.value })} />
        </div>
        <button type="submit" className="mt-6 w-full bg-amber-400 text-slate-950 font-bold rounded-xl py-3 hover:bg-amber-300">Start Free</button>
      </form>
    </main>
  );
}
